/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
String.prototype.trim=function() {
    return this.replace(/^\s*|\s*$/g,'');
}

String.prototype.ltrim=function() {
    return this.replace(/^\s*/g,'');
}

String.prototype.rtrim=function() {
    return this.replace(/\s*$/g,'');
}

/**
 * Get the JAVA_HOME directory of the currently running JVM.
 *
 * @return the JAVA_HOME directory of the currently running JVM.
 */
function getJavaHome() {
    return java.lang.System.getProperty("java.home");
}

/**
 * This method will return a random string of the specified length.
 *
 * @param length The length of the random string to generate.
 * @return A random string of length characters.
 */
function getUniqueString(length) {
    var result = "";
    var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (i = 0; i < length; ++i) {
        result += alphabet.charAt(Math.floor(Math.random() * (alphabet.length - 0.001)));
    }
    return result;
}

/**
 * Determine if the platform we are running on is a variant of Windows.
 */
function isWindows() {
    var windowsPattern = /window/i;
    var osName = getOsName()
    return windowsPattern.exec(osName) != null
}

/**
 * Return the name of the current operating system.
 */
function getOsName() {
    return java.lang.System.getProperty("os.name");
}

/**
 * Return the name of the current cpu architecture.
 */
function getOsArch() {
    var result;
    var arch = java.lang.System.getProperty("os.arch");

    if (arch.indexOf("amd64") > -1 || arch.indexOf("x64") > -1 || arch.indexOf("x86_64") > -1) {
        result = "x64";
    }
    else if (arch.indexOf("x86") > -1 || arch.indexOf("386") > -1 || arch.indexOf("486") > -1 ||
             arch.indexOf("586") > -1 || arch.indexOf("686") > -1 || arch.indexOf("pentium") > -1) {
        result = "x86";
    }
    else if (arch.indexOf("ia64") > -1 || arch.indexOf("itanium") > -1 || arch.indexOf("ia-64") > -1) {
        result = "ia64";
    }
    else if (arch.indexOf("ppc") > -1 || arch.indexOf("powerpc") > -1) {
        result = "ppc";
    }
    else if (arch.indexOf("sparc") > -1) {
        result = "sparc";
    }
    else if (arch.indexOf("parisc") > -1 || arch.indexOf("pa_risc") > -1 || arch.indexOf("pa-risc") > -1) {
        result = "parisc";
    }
    else if (arch.indexOf("alpha") > -1) {
        result = "alpha";
    }
    else if (arch.indexOf("mips") > -1) {
        result = "mips";
    }
    else if (arch.indexOf("arm") > -1) {
        result = "arm";
    }
    else {
        result = "unknown";
    }
    return result;
}

/**
 * This method takes a string and converts it into a boolean.  It will be true if the
 * value is a boolean with a true value of the string 'y', 'yes', 'true' ignoring case.
 *
 * @param value The value which we wish to evaluate as a boolean.
 * @return A boolean representation of that value.
 */
function evalBoolean(value) {
    if (value === true || value === false ) {
        return value;
    }

    if (    /^y$/i.exec(value) != null    ||
            /^yes$/i.exec(value) != null  ||
            /^true$/i.exec(value) != null )
    {
        return true;
    }
    return false;
}

function copyDirectoryWithSubstitution(srcDir, destDir, patterns, substitutions) {
    destDir.mkdirs();

    var i, j;
    var matches;
    var srcFile, destFile;
    var files = srcDir.listFiles();

    for (i = 0; i < files.length; ++i) {
        srcFile = files[i];
        destFile = null;
        if (srcFile.isDirectory()) {
            destFile = new File(destDir, srcFile.getName());
            destFile.mkdirs();
            copyDirectoryWithSubstitution(srcFile, destFile, patterns, substitutions);
        } else {
            destFile = new File(destDir, srcFile.getName());
            matches = false;
            for (j = 0; j < patterns.length; ++j) {
                var pattern = patterns[j];
                if (pattern.exec(destFile.getName()) != null) {
                    matches = true;
                    break;
                }
            }

            if (!matches) {
                copyFile(srcFile, destFile);
            } else {
                copyFileWithSubstitution(srcFile, destFile, substitutions);
            }
        }
    }
}

function copyDirectory(srcDir, destDir, excludes) {
    var i;
    var srcFile, destFile;
    var files = srcDir.listFiles();
    if (files != null) {
        for (i = 0; i < files.length; ++i) {
            srcFile = files[i];
            destFile = null;
            var excludeFile = false;
            if (excludes !== null) {
                for (var exclude in excludes) {
                    if ( ('' + srcFile.getName()).match(exclude) ) {
                        excludeFile = true;
                        break;
                    }
                }
            }
            if (!excludeFile) {
                destDir.mkdirs();
                if (srcFile.isDirectory()) {
                    destFile = new File(destDir, srcFile.getName());
                    destFile.mkdirs();
                    copyDirectory(srcFile, destFile, excludes);
                } else {
                    destFile = new File(destDir, srcFile.getName());
                    copyFile(srcFile, destFile);
                }
            }
        }
    }
}

function removeDirectoryContent(dir, excludes) {
    var files = dir.listFiles();
    if (files != null) {
        for (var i = 0; i < files.length; ++i) {
            var excludeFile = false;
            var file = files[i];
            if (excludes !== null) {
                for (var j = 0; j < excludes.length; ++j) {
                    var exclude = excludes[j];
                    if ((''+file.getName()).match(exclude)) {
                        excludeFile = true;
                        break;
                    }
                }
            }

            if (!excludeFile) {
                userInfoMsg("Deleting '" + file.getAbsolutePath() + "'.");
                if (file.isDirectory()) {
                    removeDirectoryContent(file, excludes);
                }
                file["delete"]();
            } else {
                userInfoMsg("Excluding file '" + file.getAbsolutePath() + "' : '" + file.getName() + "'.");
            }
        }
    }
}


function copyFile(srcFile, destFile) {
    userInfoMsg("Copying " + srcFile.getName() + ".");
    var fins = new FileInputStream(srcFile);
    var fouts;
    var bytesRead;
    var buf;
    try {
        fouts = new FileOutputStream(destFile);
        try {
            buf = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE,8192);
            while ((bytesRead = fins.read(buf)) != -1) {
                fouts.write(buf, 0, bytesRead);
            }
        } finally {
            fouts.close();
        }
    } finally {
        fins.close();
    }
}

function copyFileWithSubstitution(srcFile, destFile, substitutions) {
    userInfoMsg("Copying " + srcFile.getName() + " with substitution.");
    var fins = new FileInputStream(srcFile);
    var bufSize = new Array();
    var bufs = new Array();
    var totalSize = 0;
    var pos = 0;
    var fouts;
    var bytesRead;
    var buf;
    var full;
    var i;
    var size;
    var content;
    var regex;
    var key;
    var isPropertyFile;
    var propertyValue;

    try {
        // Read the entire file.
        buf = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE,8192);
        while ((bytesRead = fins.read(buf)) != -1) {
            bufs.push(buf);
            bufSize.push(bytesRead);
            totalSize += bytesRead;
            buf = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE,8192);
        }

        // Concatenate all of the byte arrays into a single byte array.
        full = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE,totalSize);
        for (i = 0; i < bufs.length; ++i) {
            size = bufSize[i];
            buf = bufs[i];
            java.lang.System.arraycopy(buf, 0, full, pos, size);
            pos += size;
        }

        isPropertyFile = destFile.getName().endsWith(".properties");

        // Generate a new string.
        content = new java.lang.String(full, "UTF-8");
        // Convert to a javscript string.
        content = "" + content;
        // perform substitution.
        for (key in substitutions) {
            regex = new RegExp("@"+key+"@", "g");
            propertyValue = '' + substitutions[key].value;
            if (isPropertyFile == true) {
                propertyValue = propertyValue.replace(/\\/g, "\\\\");
                propertyValue = propertyValue.replace(/:/g, "\\:");
                propertyValue = propertyValue.replace(/=/g, "\\=");
            }
            content = content.replace(regex, propertyValue);
        }

        // Write out the file.
        fouts = new FileOutputStream(destFile);
        try {
            fouts.write( (new java.lang.String(content)).getBytes("UTF-8"));
        } finally {
            fouts.close();
        }
    } finally {
        fins.close();
    }
}


var scales = {
    b: 1,
    B: 1,
    k: 1024,
    K: 1024,
    m: 1024 * 1024,
    M: 1024 * 1024,
    g: 1024 * 1024 * 1024,
    G: 1024 * 1024 * 1024,
    t: 1024 * 1024 * 1024 * 1024,
    T: 1024 * 1024 * 1024 * 1024,
};

// Parses a byte size limit. Valid inputs:
// - "none" or negative integers, which imply no limit.
// - Integers followed by an optional B/K/G/M/T scale.
//
// Javascript numbers are precise to the byte up to 8192T
// and produce reasonable results much higher as you are
// unlikely to care about a few bytes when you have
// petabytes of storage.
function parseBytes(value) {
    var x = /^(none|-\d+|(\d+)([KMGT]?B?))$/i.exec(value);
    var n;
    if (x === null) {
        return null;
    }
    if (/^none$/i.test(x[0]) || /^-/.test(x[0])) {
        return -1;
    }
    n = parseInt(x[2], 10);
    if (x[3] === undefined || x[3] === "") {
        return n;
    }
    return n * scales[x[3][0]];
}

// Output user information. This function should be called for information messages
// that display for either silent or non-silent (interactive) mode.
//
// NOTE: This function should not be used if a message is prompting the user for
//       input, because, in silent mode, the user will not see the message.
function userInfoMsg(s) {
    print(s);
}


// Output error message
function errorMsg(s) {
    var errStr = "";
    // If s is not empty, then prefix string with "Error: "
    if (s && s.length > 0) {
        errStr = "Error: " + s;
    }
    print(errStr);
}
