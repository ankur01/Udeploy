#!/bin/sh
# Licensed Materials - Property of IBM Corp.
# IBM UrbanCode Build
# IBM UrbanCode Deploy
# IBM UrbanCode Release
# IBM AnthillPro
# (c) Copyright IBM Corporation 2002, 2014, 2016. All Rights Reserved.
#
# U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
# GSA ADP Schedule Contract with IBM Corp.

# ---------------------------------------------------------------------------
# This command script silently installs the UrbanCode Deploy Agent Relay.
#
# A required command-line parameter is a file name that contains the
# installation properties.  An optional command-line parameter is "-fips" to
# indicate that this installation is FIPS 140-2 compliant, and if specified,
# requires a version of IBM Java that supports FIPS.
#
# See the file, example.agentrelay.install.properties, for example of
# installation properties.
#
# This script creates an output text file, agentrelay-install.log, with the
# installation results.
# This script returns an exit code of 0 if successful or 1 if failed.
# ---------------------------------------------------------------------------

# now change the dir to the root of the installer
SHELL_NAME=$0
SHELL_PATH=`dirname ${SHELL_NAME}`

if [ "." = "$SHELL_PATH" ]
then
   SHELL_PATH=`pwd`
fi
cd "${SHELL_PATH}"

PROP_FILENAME=
PROP_FILENAME_ARG=

FIPS_ARG=
if [ "-fips" = "$1" ]
then
   FIPS_ARG=-Dcom.ibm.jsse2.usefipsprovider=true
   PROP_FILENAME=$2
else  # No -fips argument in $1, check argument $2
   if [ "-fips" = "$2" ]
   then
      FIPS_ARG=-Dcom.ibm.jsse2.usefipsprovider=true
   fi
   PROP_FILENAME=$1
fi

## If the user input properties file was specified, set the cmdline parameter.
## NOTE: If the user did not specify a properties file, let the install app report the error.
if [ "" != "$PROP_FILENAME" ]
then
   PROP_FILENAME_ARG="-Duserpropfile=$PROP_FILENAME"
fi

javaCmd=java

## Production invoking silent installation:
$javaCmd $FIPS_ARG -Dsilent=true $PROP_FILENAME_ARG -cp "install/*" org.mozilla.javascript.tools.shell.Main install/install.js >agentrelay-install.log 2>&1

exit $?
