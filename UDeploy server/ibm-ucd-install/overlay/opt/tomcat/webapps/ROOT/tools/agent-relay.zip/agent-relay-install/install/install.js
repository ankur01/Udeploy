/*
 * Licensed Materials - Property of IBM Corp.
 * IBM UrbanCode Build
 * IBM UrbanCode Deploy
 * IBM UrbanCode Release
 * IBM AnthillPro
 * (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
 *
 * U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
 * GSA ADP Schedule Contract with IBM Corp.
 */
load("install/utilities.js");
load("install/prompt.js");
importPackage(java.io);
importPackage(java.security);
importPackage(com.urbancode.air.keytool);
importClass(java.lang.Thread, java.lang.Runnable, java.lang.System);
importClass(Packages.com.urbancode.commons.util.StringUtil);
importClass(Packages.com.urbancode.commons.util.crypto.CryptStringUtil);
importClass(Packages.com.urbancode.commons.util.crypto.FIPSHelper);
importClass(Packages.com.urbancode.commons.util.ssl.SSLContextProtocolDetector);

var KEYSTORE_DEFAULT = "conf/jms-relay/agentrelay.keystore";

function encryptOnce(value) {
    if (!CryptStringUtil.isEncrypted(value)) {
        return CryptStringUtil.encrypt(value);
    }
    return value;
}


var configuration = {
    AGENT_RELAY_CONNECT:       { name: "agentrelay.jms_proxy.connect"              , value: true                , type: 'boolean'  },
    AGENT_RELAY_HOME:          { name: null                                        , value: null                , type: 'string'   },
    AGENT_RELAY_ID:            { name: "agentrelay.jms_proxy.id"                   , value: getUniqueString(16) , type: 'string'   },
    AGENT_RELAY_MUTUAL_AUTH:   { name: "agentrelay.jms_proxy.mutualAuth"           , value: false               , type: 'boolean'  },
    AGENT_RELAY_NAME:          { name: "agentrelay.jms_proxy.name"                 , value: "agent-relay"       , type: 'string'   },
    AGENT_RELAY_RELAY_HOST:    { name: "agentrelay.jms_proxy.relay_host"           , value: "0.0.0.0"           , type: 'inet'     },
    AGENT_RELAY_RELAY_PORT:    { name: "agentrelay.jms_proxy.relay_port"           , value: "7916"              , type: 'port'     },
    AGENT_RELAY_SECURE:        { name: "agentrelay.jms_proxy.secure"               , value: true                , type: 'boolean'  },
    AGENT_RELAY_SERVERS:       { name: "agentrelay.jms_proxy.servers"              , value: null                , type: 'hostlist' },
    AGENTRELAY_CERT_ALIAS:     { name: "agentrelay.cert.alias"                     , value: "agentrelay"        , type: 'string'   },
    VERIFY_SERVER_IDENTITY:    { name: "verify.server.identity"                    , value: false               , type: 'boolean'  },

    // Encrypted value
    AGENTRELAY_CERT_PASS:      { name: "agentrelay.cert.password"               , value: encryptOnce("changeit"), type: 'string'   },
    AGENTRELAY_GROUP:          { name: "agentrelay.group"                          , value: "agentrelay"        , type: 'string'   },
    AGENTRELAY_KEYSTORE:       { name: "agentrelay.keystore"                       , value: KEYSTORE_DEFAULT    , type: 'string'   },
    // Encrypted value
    AGENTRELAY_KEYSTORE_PASS:  { name: "agentrelay.keystore.password"           , value: encryptOnce("changeit"), type: 'string'   },
    AGENTRELAY_USER:           { name: "agentrelay.user"                           , value: "agentrelay"        , type: 'string'   },
    ARCH:                      { name: "cpu_arch"                                  , value: getOsArch()         , type: 'string'   },
    INSTALL_SERVICE:           { name: "agentrelay.install.service"                , value: false               , type: 'boolean'  },
    INSTALL_SERVICE_AUTOSTART: { name: "agentrelay.install.service.autostart"      , value: false               , type: 'boolean'  },
    INSTALL_SERVICE_LOGIN:     { name: "agentrelay.install.service.login"          , value: ".\\localsystem"    , type: 'string'   },
    INSTALL_SERVICE_NAME:      { name: "agentrelay.install.service.name"           , value: "agentrelay"        , type: 'string'   },
    // Encrypted value
    INSTALL_SERVICE_PASSWORD:  { name: "agentrelay.install.service.password"      , value: encryptOnce("nopass"), type: 'string'   },
    JAVA_HOME:                 { name: "java.home"                                 , value: getJavaHome()       , type: 'string'   },
    JAVA_OPTS:                 { name: "java.opts"                                 , value: "-Xmx1024m"         , type: 'string'   },
    PROXY_HOST:                { name: "agentrelay.http_proxy.host"                , value: "0.0.0.0"           , type: 'inet'     },
    PROXY_PORT:                { name: "agentrelay.http_proxy.port"                , value: "20080"             , type: 'port'     },
    REPLICATION_ENABLE:        { name: "agentrelay.codestation.enable_replication" , value: false               , type: 'boolean'  },
    REPLICATION_GEOTAGS:       { name: "agentrelay.codestation.geotags"            , value: null                , type: 'string'   },
    REPLICATION_MAX_CACHE:     { name: "agentrelay.codestation.max_cache_size"     , value: "none"              , type: 'string'   },
    // Encrypted value
    REPLICATION_SERVER_PASS:   { name: "agentrelay.codestation.server_password"    , value: null                , type: 'string'   },
    REPLICATION_SERVER_URL:    { name: "agentrelay.codestation.server_url"         , value: null                , type: 'string'   }
};

// List of configuration properties optionally available in the user input file
// for a new installation. If this is an upgrade installation, these properties do not apply.
// This list excludes the Windows-only properties (service installation properties).
var configUserInputPropArr = [
    configuration.JAVA_HOME,                    // name: "java.home"
    configuration.AGENT_RELAY_NAME,             // name: "agentrelay.jms_proxy.name"
    configuration.PROXY_HOST,                   // name: "agentrelay.http_proxy.host"
    configuration.PROXY_PORT,                   // name: "agentrelay.http_proxy.port"
    configuration.AGENT_RELAY_RELAY_HOST,       // name: "agentrelay.jms_proxy.relay_host"
    configuration.AGENT_RELAY_RELAY_PORT,       // name: "agentrelay.jms_proxy.relay_port"
    configuration.AGENT_RELAY_SERVERS,          // name: "agentrelay.jms_proxy.servers"
    configuration.AGENTRELAY_USER,              // name: "agentrelay.user"
    configuration.AGENTRELAY_GROUP,             // name: "agentrelay.group"
    configuration.AGENT_RELAY_MUTUAL_AUTH,      // name: "agentrelay.jms_proxy.mutualAuth"
    configuration.REPLICATION_ENABLE,           // name: "agentrelay.codestation.enable_replication"
    configuration.REPLICATION_GEOTAGS,          // name: "agentrelay.codestation.geotags"
    configuration.REPLICATION_MAX_CACHE,        // name: "agentrelay.codestation.max_cache_size"
    configuration.REPLICATION_SERVER_PASS,      // name: "agentrelay.codestation.server_password"
    configuration.REPLICATION_SERVER_URL,       // name: "agentrelay.codestation.server_url"
    configuration.VERIFY_SERVER_IDENTITY        // name: "verify.server.identity"
];

// List of Windows-only, configuration properties
var configUserInputWindowsPropArr = [
    configuration.INSTALL_SERVICE,              // name: "agentrelay.install.service"
    configuration.INSTALL_SERVICE_AUTOSTART,    // name: "agentrelay.install.service.autostart"
    configuration.INSTALL_SERVICE_LOGIN,        // name: "agentrelay.install.service.login"
    configuration.INSTALL_SERVICE_NAME,         // name: "agentrelay.install.service.name"
    configuration.INSTALL_SERVICE_PASSWORD     // name: "agentrelay.install.service.password"
];


// These properties no longer exist in the properties file, and have been
// replaced by AGENT_RELAY_SERVERS. See function switchToMultiServerFormat().
var OLD_SERVER_HOST_PROPERTY_NAME = "agentrelay.jms_proxy.server_host";
var OLD_SERVER_PORT_PROPERTY_NAME = "agentrelay.jms_proxy.server_port";
var OLD_AGENTRELAY_KEYSTORE_PASS = "agentrelay.codestation.keystore_password";
var OLD_AGENTRELAY_CERT_ALIAS = "agentrelay.codestation.cert_alias";
var OLD_AGENTRELAY_CERT_PASS = "agentrelay.codestation.cert_password";

var USER_INPUT_RELAY_HOME_DIR_PROP_NAME = "agentrelay.home";

// Optional, command-line parameters:
var DEBUG_INFO_PARAMETER_NAME = "debug";
var SILENT_MODE_PARAMETER_NAME = "silent";
var USER_INPUT_FILENAME_PARAMETER_NAME = "userpropfile";

var EXIT_CODE_OK = 0;
var EXIT_CODE_FAILED = 1;

var exitCode = EXIT_CODE_OK;

var upgrade = false;
var defaultValues = new java.util.Properties();
var prompter = null;

var silentModeArgValue = System.getProperty(SILENT_MODE_PARAMETER_NAME);
var silentMode = evalBoolean(silentModeArgValue);

// Check user input filename, if found, read properties from it.
var userInputValues = null;
var userInputFilename = System.getProperty(USER_INPUT_FILENAME_PARAMETER_NAME);
if (userInputFilename !== null && userInputFilename.length() > 0) {
    if (silentMode) {
        userInputValues = readUserInputFile(userInputFilename);
    }
    else {
        userInfoMsg("Ignoring specified user input file, only applies when installation is in silent mode");
    }
}

// If silentMode, check that we have user input values (from input file), if not, produce error.
if (exitCode === EXIT_CODE_OK) {
    if (silentMode && userInputValues === null) {
        errorMsg("User input file is required in silent mode");
        exitCode = EXIT_CODE_FAILED;
    }
}

// If everything is good up to this point, continue processing.
if (exitCode === EXIT_CODE_OK) {
    if (FIPSHelper.isFipsRequested()) {
        FIPSHelper.enableFips();
        userInfoMsg("*********************************");
        userInfoMsg("FIPS 140-2 Compliant Mode Enabled");
        userInfoMsg("*********************************");
    }

    if (silentMode) {
        getSilentInstallParams();
    }
    else {
        promptForInstallParams();
    }
}


if (exitCode === EXIT_CODE_OK) {
    performInstallation();
    displaySuccessMessage();
}

// Set return code, 0 if ok, else value greater than 0
java.lang.System.exit(exitCode);

// -------------------------------------------------------------------------------------------
// ----------------------------------- End of main execution ---------------------------------
// -------------------------------------------------------------------------------------------

// If not silent mode, prompt user for installation configuration parameters
function promptForInstallParams() {

    var verifyServerIdentityPromptText =
        "Enable the agent relay to verify the server HTTPS certificate? If enabled, you must import the server certificate" +
            " to the JRE keystore on the agent relay. y,N [Default: N]";

    prompter = new Prompter();

    // This prompts for the installation directory, then determines
    // if this is an upgrade (and sets global flag, upgrade).
    configuration.AGENT_RELAY_HOME.value = getAgentRelayHome();

    if (upgrade) {
        // If previous configuration (properties in "defaultValues" dictionary)
        // is missing new properties, prompt for those.
        if (!defaultValues.containsKey(configuration.VERIFY_SERVER_IDENTITY.name)) {
            configuration.VERIFY_SERVER_IDENTITY.value = prompter.promptBoolean(
                verifyServerIdentityPromptText,
                configuration.VERIFY_SERVER_IDENTITY.value);
        }
    }
    else {  // new installation
        configuration.JAVA_HOME.value = prompter.prompt(
            "Enter the home directory of the JRE/JDK used to run the Agent Relay.", configuration.JAVA_HOME.value);

        configuration.AGENT_RELAY_NAME.value = prompter.prompt(
            "Enter a unique name for this relay.", configuration.AGENT_RELAY_NAME.value);
        configuration.PROXY_HOST.value = prompter.promptInetAddress(
            "Enter the IP address or host name that this Agent Relay listens for requests on.", configuration.PROXY_HOST.value);
        configuration.AGENT_RELAY_RELAY_HOST.value = configuration.PROXY_HOST.value;
        configuration.PROXY_PORT.value = prompter.promptPort(
            "Enter the port number that this Agent Relay listens for proxy HTTP requests on.", configuration.PROXY_PORT.value);
        configuration.AGENT_RELAY_RELAY_PORT.value = prompter.promptPort(
            "Enter the port number that this Agent Relay uses for JMS communication.", configuration.AGENT_RELAY_RELAY_PORT.value);

        configuration.AGENT_RELAY_CONNECT.value = prompter.promptBoolean(
            "Do you want to connect the agent relay to one or more central servers?", configuration.AGENT_RELAY_CONNECT.value);
        if (configuration.AGENT_RELAY_CONNECT.value) {
            var addServer = true;
            configuration.AGENT_RELAY_SERVERS.value = "";
            while (addServer) {
                var host = prompter.promptInetAddress("Enter the hostname or address of the server that this relay will connect to.")
                var port = prompter.promptPort("Enter the agent JMS communication port number for this server.", 7918);
                configuration.AGENT_RELAY_SERVERS.value += host + ":" + port;
                addServer = prompter.promptBoolean("Do you want to configure an additional connection for failover scenarios?", false);
                if (addServer) {
                    configuration.AGENT_RELAY_SERVERS.value += ",";
                }
            }
        }

        configuration.AGENT_RELAY_MUTUAL_AUTH.value = prompter.promptBoolean(
            "Do you want to use mutual authentication between the agent, relay and server?", configuration.AGENT_RELAY_MUTUAL_AUTH.value);

        configuration.VERIFY_SERVER_IDENTITY.value = prompter.promptBoolean(
            verifyServerIdentityPromptText,
            configuration.VERIFY_SERVER_IDENTITY.value);

        configureCodestation();

        print("We have detected that you are running " + getOsName() + ".");
        print("We have detected your CPU architecture as '" + configuration.ARCH.value + "'.");
        if (isWindows()) {
            if (configuration.ARCH.value.indexOf("x86") == -1 && configuration.ARCH.value.indexOf("x64") == -1) {
                print("We do not support installing the Agent Relay as a windows service on this architecture '" + configuration.ARCH.value + "'.");
            }
            else {
                // get configuration for service installation.
                configuration.INSTALL_SERVICE.value = prompter.promptBoolean(
                    "Do you want to install the Agent Relay as Windows service?", configuration.INSTALL_SERVICE.value);
                if (configuration.INSTALL_SERVICE.value == true) {
                    configuration.INSTALL_SERVICE_NAME.value = prompter.prompt(
                        "Enter a unique service name for the Agent Relay. No spaces please.", configuration.INSTALL_SERVICE_NAME.value);
                    configuration.INSTALL_SERVICE_LOGIN.value = prompter.prompt(
                        "Enter the user account name including domain path to run the service as (for local use '.\\' before login).", configuration.INSTALL_SERVICE_LOGIN.value);
                    configuration.INSTALL_SERVICE_PASSWORD.value = encryptOnce(prompter.prompt(
                        "Enter the password for the '" + configuration.INSTALL_SERVICE_LOGIN.value + "' user account.",
                        configuration.INSTALL_SERVICE_PASSWORD.value, true));
                    configuration.INSTALL_SERVICE_AUTOSTART.value = prompter.promptBoolean(
                        "Do you want to start the service automatically?", configuration.INSTALL_SERVICE_AUTOSTART.value);
                }
            }
        }
        else {
            configuration.AGENTRELAY_USER.value = prompter.prompt(
                "Which user do you want to run the agent relay?", configuration.AGENTRELAY_USER.value);
            configuration.AGENTRELAY_GROUP.value = prompter.prompt(
                "Which group do you want to run the agent relay?", configuration.AGENTRELAY_GROUP.value);
        }
    }
}

function displaySuccessMessage() {
    if (upgrade == true) {
        userInfoMsg("You have successfully upgraded the Agent Relay.");
    }
    else {
        userInfoMsg("You have successfully installed the Agent Relay.");
    }
    userInfoMsg("");
    userInfoMsg("You may now start the relay by changing to the " + configuration.AGENT_RELAY_HOME.value + " directory");
    userInfoMsg("and running the following command.");
    userInfoMsg("");
    if (isWindows()) {
        userInfoMsg("\tbin\\agentrelay start");
    }
    else {
        userInfoMsg("\t# bin/agentrelay start");
    }
    userInfoMsg("");
}

// Returns new java.util.Properties() if file was found
function readUserInputFile(filename) {
    // Check user input filename, if found, read properties from it.
    var retUserInputValues = null;
    var inputStream = null;
    var success = false;
    var errMsg = null;

    try {
        var inputFile = new java.io.File(filename);

        if (!inputFile.exists()) {
            errMsg = "User input file [" + filename + "] was not found.";
        }
        else if (!inputFile.canRead()) {
            errMsg = "User input file [" + filename + "] cannot be read by the current user.";
        }
        else { // If file exists, read properties from it.
            retUserInputValues = new java.util.Properties();
            inputStream = new java.io.FileInputStream(filename);
            retUserInputValues.load(inputStream);
            success = true;
        }
    }
    finally {
        if (inputStream) {
            inputStream.close();
        }
    }

    // If failed,
    if (!success) {
        // If errMsg is not already set, use generic msg
        if (errMsg === null) {
            errMsg = "User input file [" + filename + "] error";
        }
        errorMsg(errMsg);
        exitCode = EXIT_CODE_FAILED;
    }

    return retUserInputValues;
}


function performInstallation() {
    userInfoMsg("--------------------------------------------------------------------------------");
    userInfoMsg("Beginning installation of the Agent Relay.");
    userInfoMsg("--------------------------------------------------------------------------------");
    userInfoMsg("");
    var agentRelayHome = new File(configuration.AGENT_RELAY_HOME.value);
    if (upgrade == true) {
        if (configuration.INSTALL_SERVICE.value == true) {
            performServiceRemoval();
        }
        // Encrypt potentially unencrypted values from old installation
        configuration.REPLICATION_SERVER_PASS.value =
            encryptOnce(configuration.REPLICATION_SERVER_PASS.value);
        configuration.INSTALL_SERVICE_PASSWORD.value =
            encryptOnce(configuration.INSTALL_SERVICE_PASSWORD.value);
        configuration.AGENTRELAY_KEYSTORE_PASS.value =
            encryptOnce(configuration.AGENTRELAY_KEYSTORE_PASS.value);
        configuration.AGENTRELAY_CERT_PASS.value =
            encryptOnce(configuration.AGENTRELAY_CERT_PASS.value);
        // backup existing installation
        backupExistingInstallation(agentRelayHome);
        // remove directory.
        removeExistingInstallation(agentRelayHome);
    }
    copyDirectory(new File("lib"), new File(agentRelayHome, "lib"));
    copyDirectory(new File("var"), new File(agentRelayHome, "var"));
    copyDirectoryWithSubstitution(
        new File("conf"), new File(agentRelayHome, "conf"), [/^agentrelay\.properties$/], configuration);
    copyDirectoryWithSubstitution(
        new File("bin"), new File(agentRelayHome, "bin"), [/[^(\.jar)]$/], configuration);

    // Set the executable permissions on the startup scripts.
    installPermissions(agentRelayHome)

    // Generate SSL key for the JMS broker.
    var confDir = new File(agentRelayHome, "conf");
    var jmsConfDir = new File(confDir, "jms-relay");
    var keystoreFile = new File(jmsConfDir, "agentrelay.keystore");
    if (!keystoreFile.exists()) {
        userInfoMsg("Generating SSL key for agent relay.");
        userInfoMsg(keystoreFile.getAbsolutePath());
        generateSSLKey(keystoreFile);
    }
    userInfoMsg("--------------------------------------------------------------------------------");
    userInfoMsg("Finished installation of Agent Relay.");
    userInfoMsg("--------------------------------------------------------------------------------");
    if (configuration.INSTALL_SERVICE.value == true) {
        performServiceInstallation();
    }
}

function performServiceRemoval() {
    userInfoMsg("--------------------------------------------------------------------------------");
    userInfoMsg("Beginning removal of Agent Relay Service.");
    userInfoMsg("--------------------------------------------------------------------------------");
    userInfoMsg("");

    var runFrom = new File(new File(new File(configuration.AGENT_RELAY_HOME.value), "bin"), "service");

    userInfoMsg("Removing existing service installation.");
    runCommand(
        [
            "CMD.EXE",
            "/C",
            "agentrelay.cmd",
            "remove",
            configuration.INSTALL_SERVICE_NAME.value
        ],
        runFrom);

    userInfoMsg("--------------------------------------------------------------------------------");
    userInfoMsg("Finished removal of Agent Relay Service.");
    userInfoMsg("--------------------------------------------------------------------------------");
}

function performServiceInstallation() {
    userInfoMsg("--------------------------------------------------------------------------------");
    userInfoMsg("Beginning installation of Agent Relay Service.");
    userInfoMsg("--------------------------------------------------------------------------------");
    userInfoMsg("");

    var runFrom = new File(new File(new File(configuration.AGENT_RELAY_HOME.value), "bin"), "service");

    // Perform the installation.
    runCommand(
        [
            "cscript.exe",
            "//I",
            "//Nologo",
            "//H:CScript",
            "agentrelay_srvc_install.vbs",
            configuration.INSTALL_SERVICE_NAME.value,
            configuration.INSTALL_SERVICE_LOGIN.value,
            CryptStringUtil.decrypt(configuration.INSTALL_SERVICE_PASSWORD.value),
            configuration.INSTALL_SERVICE_AUTOSTART.value
        ],
        runFrom);

    userInfoMsg("--------------------------------------------------------------------------------");
    userInfoMsg("Finished installation of Agent Relay Service.");
    userInfoMsg("--------------------------------------------------------------------------------");
}

function runCommand(cmdArray, runFrom) {
    userInfoMsg("Working Directory: " + runFrom.getAbsolutePath());
    userInfoMsg("Executing: " + cmdArray.join(" "));

    var runtime = java.lang.Runtime.getRuntime();
    var process = runtime.exec(cmdArray, null, runFrom);
    userInfoMsg("Process launched, waiting for completion.");

    var ins = process.getInputStream();
    try {
        var err = process.getErrorStream();
        try {
            var stdoutPumper = new Thread(new Runnable() {
                run: function() {
                    var bytesRead;
                    var buf = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 8192);
                    while ((bytesRead = ins.read(buf)) != -1) {
                        System["out"].write(buf, 0, bytesRead);
                    }
                }
            });

            var stderrPumper = new Thread(new Runnable() {
                run: function() {
                    var bytesRead;
                    var buf = java.lang.reflect.Array.newInstance(java.lang.Byte.TYPE, 8192);
                    while ((bytesRead = err.read(buf)) != -1) {
                        System["err"].write(buf, 0, bytesRead);
                    }
                }
            });

            stdoutPumper.start();
            stderrPumper.start();
            stdoutPumper.join();
            stderrPumper.join();
            process.waitFor();
        }
        finally {
            err.close();
        }
    }
    finally {
        ins.close();
    }
}

function backupExistingInstallation(agentRelayHome) {
    var backups = new File(agentRelayHome, "backups");
    var toDir = new File(backups, (new Date()).toUTCString().replace(/[ ,:]/gi, "_").toString());
    userInfoMsg("Backing up existing installation to '" + toDir.getCanonicalPath() + "'.");
    copyDirectory(agentRelayHome, toDir, [/^backups$/]);
}

function removeExistingInstallation(agentRelayHome) {
    userInfoMsg("Removing old installation at '" + agentRelayHome.getCanonicalPath() + "'.");
    removeDirectoryContent(agentRelayHome, [/^backups$/, /^agentrelay\.keystore$/]);
}

function generateSSLKey(keyFile) {
    var project = new org.apache.tools.ant.Project();
    project.setBasedir(".");

    var from = new Date();
    var to = new Date(from.getTime() + (7305 * 86400000));

    var keyHelper = new com.urbancode.air.keytool.KeytoolHelper();

    var ks = keyHelper.generateKeyStore(keyFile, "JKS", "changeit");
    var pair = keyHelper.generateKeyPair("RSA", 2048);

    var privKey = pair.getPrivate();
    var pubKey = pair.getPublic();

    var extension = new com.urbancode.air.keytool.Extension(pubKey, false);
    extension.SetExtensionIdentifierAsSubjectKey();
    var extensions = new java.util.ArrayList();
    extensions.add(extension);

    var cert = keyHelper.buildWithExtensions("CN=agentrelay", from, to, pair, "SHA256WithRSA", extensions);
    var certArray = [cert]

    ks.setKeyEntry("agentrelay", privKey, "changeit".split(''), certArray);
    ks.store(new FileOutputStream(keyFile.getAbsolutePath()), "changeit".split(''));
}

function installPermissions(agentRelayHome) {
    if (!isWindows()) {
        var binDir = new File(agentRelayHome, "bin");
        var binAgentrelay = new File(binDir, "agentrelay");
        var initDir = new File(binDir, "init");
        var initAgentrelay = new File(initDir, "agentrelay");

        var project = new org.apache.tools.ant.Project();
        project.setBasedir(agentRelayHome.getAbsolutePath());
        var chmod = new org.apache.tools.ant.taskdefs.Chmod();
        chmod.setProject(project);

        userInfoMsg("Setting permissions on " + binAgentrelay.getAbsolutePath());
        chmod.setPerm("755");
        chmod.setFile(binAgentrelay);
        chmod.execute();

        userInfoMsg("Setting permissions on " + initAgentrelay.getAbsolutePath());
        chmod.setPerm("755");
        chmod.setFile(initAgentrelay);
        chmod.execute();
    }
}


// This function prompts for the installation directory, then checks that it's a
// directory with read permission.  It then checks for an existing installation,
// and if so, then prompts the user whether this is an upgrade or a new installation.
// If this is an upgrade, then it reads the properties from the
// file: "conf/agentrelay.properties" .
function getAgentRelayHome() {
    var agentRelayHome;
    var createAgentRelayHome;
    var success = false;
    while (!success) {
        var defaultValue = "/opt/ibm/agentrelay";
        if (isWindows()) {
            defaultValue = "C:\\Program Files\\IBM\\agentrelay";
        }
        agentRelayHome = prompter.prompt(
            "Enter the directory to install the agent relay into.", defaultValue);
        var agentRelayHomeFile = new java.io.File(agentRelayHome);
        if (!agentRelayHomeFile.exists()) {
            // prompt to create it.
            createAgentRelayHome = prompter.promptBoolean("The specified directory does not exist. Do you want to create it?", true);
            if (createAgentRelayHome == true) {
                success = true;
            }
        }
        else {
            if (!agentRelayHomeFile.isDirectory()) {
                print("This path is not a directory.");
            }
            else if (!agentRelayHomeFile.canRead()) {
                print("This path cannot be read by the current user.");
            }
            else {
                success = true;
                // check for upgrade
                var propertiesFile = new java.io.File(new java.io.File(agentRelayHomeFile, "conf"), "agentrelay.properties");
                if (propertiesFile.exists()) {
                    upgrade = prompter.promptBoolean("The specified directory appears to contain an existing installation. Do you want to upgrade it?", true);
                    if (upgrade === true) {
                        var inputStream = new java.io.FileInputStream(propertiesFile);
                        defaultValues.load(inputStream);
                        inputStream.close();

                        // Update our default values.
                        var propertyNames = defaultValues.propertyNames();
                        while (propertyNames.hasMoreElements()) {
                            var propertyName = propertyNames.nextElement();
                            for (var key in configuration) {
                                if (configuration[key].name !== null && propertyName.equals(configuration[key].name)) {
                                    if (configuration[key].type == 'boolean') {
                                        configuration[key].value = evalBoolean(defaultValues.getProperty(propertyName));
                                    }
                                    else {
                                        configuration[key].value = defaultValues.getProperty(propertyName);
                                    }
                                    break;
                                }
                            }
                        }

                        // Add codestation config if upgrading from pre 6.1
                        configureCodestation();

                        // Convert properties to multi-server failover format if upgrading from pre 6.1.1.1
                        switchToMultiServerFormat();

                        // Convert properties to standardized agentrelay keystore format if upgrading from pre 6.1.1.1
                        // and there are some user defined values already.
                        configureKeystoreProperties();
                    }
                    else {
                        success = false;
                    }
                }
            }
        }
    }

    return agentRelayHome;
}


// This function (silently, no user prompts) checks the user-specified installation directory,
// and also checks that the directory is actually a directory with write permission.
// It then checks for an existing installation, and if so, sets the upgrade (global var).
//
// If this is an upgrade, then it reads the properties from the
// file: "conf/agentrelay.properties".
//
// If there is an error, the global variable, exitCode, is set to EXIT_CODE_FAILED (1).
//
// returns path to agentRelayHome directory
//
function getSilentInstallParams() {
    var agentRelayHome = null;
    var createAgentRelayHome;
    var validOsSystem = true;
    var success = true;

    if (isWindows()) {
        if (configuration.ARCH.value.indexOf("x86") == -1 && configuration.ARCH.value.indexOf("x64") == -1) {
            exitCode = EXIT_CODE_FAILED;
            validOsSystem = false;
            errorMsg("We do not support installing the Agent Relay as a windows service on this architecture '" +
                configuration.ARCH.value + "'.");
        }
    }

    if (validOsSystem) {
        // Read values from user input properties file and set in global object, configuration.
        // This function may cause the exit code to be set, so check the exit code before proceeding.
        // This will may set the global variable, "upgrade".
        applySilentInstallHomeDirAndUpgradeFlag();

        if (exitCode === EXIT_CODE_OK) {
            agentRelayHome = configuration.AGENT_RELAY_HOME.value;
            var agentRelayHomeFile = new java.io.File(agentRelayHome);

            if (upgrade) {
                // At this point, the home directory does exist and contains
                // the file, conf/agentrelay.properties. Read the properties from that file.
                var propertiesFile = new java.io.File(new java.io.File(agentRelayHomeFile, "conf"), "agentrelay.properties");
                var inputStream = new java.io.FileInputStream(propertiesFile);
                success = false; // this gets set to true if we find assign at least 1 property from previous conf file.

                defaultValues.load(inputStream);
                inputStream.close();

                // At this point, "defaultValues" is a dictionary of properties read from
                // previous installation file, conf/agentrelay.properties.
                //
                // Assign the values found in the "defaultValues" to the values
                // in the array, "configuration".
                var propertyNames = defaultValues.propertyNames();
                while (propertyNames.hasMoreElements()) {
                    var propertyName = propertyNames.nextElement();
                    for (var key in configuration) {
                        if (configuration[key].name !== null && propertyName.equals(configuration[key].name)) {
                            if (configuration[key].type == 'boolean') {
                                configuration[key].value = evalBoolean(defaultValues.getProperty(propertyName));
                            }
                            else {
                                configuration[key].value = defaultValues.getProperty(propertyName);
                            }
                            success = true; // found least one property, set success to true
                            break;
                        }
                    }
                }
            }

            // If no properties processed (success == false), return error
            if (!success) {
                exitCode = EXIT_CODE_FAILED;
                errorMsg("Upgrade requires previous file with valid properties: " + propertiesFile.getAbsolutePath());
            }
            else {
                // For new install, this applies all of the properties from the user input file.
                // In the case of an upgrade, we honor all of the property values stored
                // in conf/agentrelay.properties, however, any new properties not in
                // this file, may be added via the specified "user input file".
                applyUserInputValues();
            }
        }
    }

    return agentRelayHome;
}


// Apply the property values for installation home directory and the global upgrade flag, "upgrade".
// The installation home directory path gets set in configuration.AGENT_RELAY_HOME.value.
// If there is an error, the global variable, exitCode, is set to EXIT_CODE_FAILED (1).
function applySilentInstallHomeDirAndUpgradeFlag() {

    // Special handling for the relay installation directory property from in the user input properties file.
    var installHomeDirValue = userInputValues.getProperty(USER_INPUT_RELAY_HOME_DIR_PROP_NAME);

    // Error if home directory was not specified in user input file.
    if (installHomeDirValue === null || installHomeDirValue.length === 0) {
        exitCode = EXIT_CODE_FAILED;
        errorMsg(USER_INPUT_RELAY_HOME_DIR_PROP_NAME + " property is required and must be specified");
    }
    else {
        configuration.AGENT_RELAY_HOME.value = installHomeDirValue;

        // Determine if this is a new installation or an upgrade,
        // it returns null if a problem was detected (and sets the exitCode).
        var isUpgrade = checkSilentUpgrade(installHomeDirValue);

        // If above returned non-null, set global var, upgrade, and proceed.
        if (isUpgrade !== null) {
            upgrade = isUpgrade; // set global variable
        }
    }
}


// Apply the property values from the user input file to the configuration object.
//
// For new install, this applies all of the properties from the user input file.
// In the case of an upgrade, we honor all of the property values stored
// in conf/agentrelay.properties, however, any new properties not in
// this file, may be added via the specified "user input file".
//
// We will now read the properties from the "user input file" and if the
// user input file has properties that are NOT IN "defaultValues", then
// add at value to the array, "configuration".
function applyUserInputValues() {

    // For each propery, check if the user may have provided a value, if so, apply
    // the value to the global configuration object.
    // If the exitCode is set, keep processing (don't check) so that we can give
    // the user all of error messages.
    // NOTE: Each element in configUserInputPropArr is a reference to an object in "configuration".
    for each (var configItem in configUserInputPropArr) {
        // Apply value from user input file if this is a new installation or this property name
        // in not found in the "defaultValues" (values read from current conf properties file).
        if (!upgrade || !defaultValues.containsKey(configItem.name)) {
            helperApplyUserInputProp(configItem);
        }
    }

    // If Windows system, process the Windows-only properties
    if (isWindows()) {
        // For each propery, check if the user may have provided a value, if so, apply
        // the value to the global configuration object.
        // NOTE: Each element in configUserInputWindowsPropArr is a reference to an object in "configuration".
        for each (var winConfigItem in configUserInputWindowsPropArr) {
            // Apply value from user input file if this is a new installation or this property name
            // in not found in the "defaultValues" (values read from current conf properties file).
            if (!upgrade || !defaultValues.containsKey(winConfigItem.name)) {
                helperApplyUserInputProp(winConfigItem);
            }
        }
    }
}


// Given the user-specified install home directory, determine if this
// is a new installation or an upgrade.
// Returns true if upgrade, false if new, null if error (and sets exitCode).
function checkSilentUpgrade(agentRelayHome) {
    var isUpgrade = false;  // return value

    var agentRelayHomeFile = new java.io.File(agentRelayHome);
    if (agentRelayHomeFile.exists()) {

        if (!agentRelayHomeFile.isDirectory()) {
            exitCode = EXIT_CODE_FAILED;
            errorMsg("Directory specified on " + USER_INPUT_RELAY_HOME_DIR_PROP_NAME + " property " +
                "[" + agentRelayHome + "] must be a directory");
        }
        else if (!agentRelayHomeFile.canRead()) {
            exitCode = EXIT_CODE_FAILED;
            errorMsg("Directory specified on " + USER_INPUT_RELAY_HOME_DIR_PROP_NAME + " property " +
                "[" + agentRelayHome + "] cannot be read by the current user");
        }
        else if (!agentRelayHomeFile.canWrite()) {
            exitCode = EXIT_CODE_FAILED;
            errorMsg("Directory specified on " + USER_INPUT_RELAY_HOME_DIR_PROP_NAME + " property " +
                "[" + agentRelayHome + "] cannot be written to by the current user");
        }
        else {
            // Test if <agentRelayHome>/conf directory exists and that it's readable, and also
            // whether it contains the file, <agentRelayHome>/conf/agentrelay.properties. If so,
            // then assume this is an upgrade.
            var confDirFile = new java.io.File(agentRelayHomeFile, "conf");
            if (confDirFile.exists()) {

                if (!confDirFile.isDirectory()) {
                    exitCode = EXIT_CODE_FAILED;
                    errorMsg("Directory expected at: " + confDirFile.getAbsolutePath());
                }
                else if (!confDirFile.canRead()) {
                    exitCode = EXIT_CODE_FAILED;
                    errorMsg("Directory [" + confDirFile.getAbsolutePath() + "] cannot be read by the current user.");
                }
                else {
                    var propertiesFile = new java.io.File(confDirFile, "agentrelay.properties");
                    if (propertiesFile.exists()) {
                        isUpgrade = true;
                    }
                }
            }
        }
    }

    return isUpgrade;
}


// Given a reference to an item in global variable, configuration,
// retrieve the value for this property from the user input file
// and set the value in the configuration item (configItemRef).
function helperApplyUserInputProp( configItemRef ) {
    var propName = configItemRef.name;
    var propUserValue = userInputValues.getProperty(propName);

    // If the user value is not null, then evaluate it and set it in configuration.
    if (propUserValue !== null) {

        if (propName.equals(configuration.REPLICATION_GEOTAGS.name)) {
            // Special handling for the property:
            // configuration.REPLICATION_GEOTAGS (name: agentrelay.codestation.geotags)
            parseUserPropGeoTags(configItemRef, propUserValue);
        }
        else if (propName.equals(configuration.REPLICATION_MAX_CACHE.name)) {
            // Special processing for agentrelay.codestation.max_cache_size,
            // its value can be an integer or integer followed by K, M, G, or T.
            parseUserPropCacheMax(configItemRef, propUserValue);
        }
        else { // else, just set string value
            if (configItemRef.type == 'boolean') {
                configItemRef.value = evalBoolean(propUserValue);
            }
            else if (configItemRef.type == 'inet') {
                parseUserInetAddressValue(configItemRef, propUserValue);
            }
            else if (configItemRef.type == 'port') {
                parseUserPortValue(configItemRef, propUserValue);
            }
            else if (configItemRef.type == 'hostlist') {
                parseUserHostlistValue(configItemRef, propUserValue);
            }
            else {
                configItemRef.value = propUserValue;
            }
        }
    }
}

// Parses and sets the geotags configuration item given the property value
// from the user input file.
function parseUserPropGeoTags(configItemRef, propUserValue) {

    // Split the tags by ";", escape them, then rejoin them with commas.
    var GeoTagListParser = Packages.com.ibm.uclab.csrepl.ptrstore.GeoTagListParser;
    var geoTagStrArr = propUserValue.split(";");

    if (geoTagStrArr !== null && geoTagStrArr.length > 0)
    {
        for (var i = 0, len = geoTagStrArr.length; i < len; i++) {
            geoTagStrArr[i] = GeoTagListParser.escapeTag(geoTagStrArr[i]);
        }
    }
    configItemRef.value = geoTagStrArr.join(",");
}

// Parses and sets the cache limit configuration item given the property value
// from the user input file.
function parseUserPropCacheMax(configItemRef, propUserValue) {

    // Special processing for agentrelay.codestation.max_cache_size,
    // its value can be an integer or integer followed by K, M, G, or T.
    var limit = null;
    var propName = configItemRef.name;

    if (propUserValue != "") {
        propUserValue = propUserValue.trim();
        limit = parseBytes(propUserValue);

        if (limit == null) {
            errorMsg("Invalid byte limit for property " + propName + " value: " + propUserValue);
            exitCode = EXIT_CODE_FAILED;
        }
        else {
            configItemRef.value = String(limit);
        }
    }
}

// Parses and sets the tcp port configuration item given the property value
// from the user input file.
function parseUserPortValue(configItemRef, propUserValue) {
    var portIntVal = Number.NaN;
    var propName = configItemRef.name;

    // interpret user specified value.
    if (propUserValue != "") {
        portIntVal = parseInt(propUserValue);
    }

    // validate value
    if (isNaN(portIntVal) || portIntVal < 0 || portIntVal > 65535) {
        errorMsg("Invalid port number for property " + propName + " value: " + propUserValue +
            ", port number must be 0..65535");
        exitCode = EXIT_CODE_FAILED;
    }
    else {
        configItemRef.value = portIntVal;
    }
}

// Parses and sets the Inet address configuration item given the property value
// from the user input file.
function parseUserInetAddressValue(configItemRef, propUserValue) {
    var value = propUserValue;
    var propName = configItemRef.name;

    if (value != "") {
        value = value.trim();
        if (!validateInetAddress(value)) {
            value = null;
        }
    }
    else {
        value = null;
    }

    // validate value
    if (value === null) {
        errorMsg("Invalid internet address for property " + propName + " value: " + propUserValue);
        exitCode = EXIT_CODE_FAILED;
    }
    else {
        configItemRef.value = value; // use trimmed value
    }
}

// Parses and sets the host list (ipaddr:port,ipaddr:port,etc) configuration item given the property value
// from the user input file.
function parseUserHostlistValue(configItemRef, propUserValue) {
    var value = propUserValue;
    var propName = configItemRef.name;
    var valid = true;

    if (value != "") {
        value = value.trim();
        // Split the values by ','s.
        var addrArr = value.split(",");

        if (addrArr.length > 0) {
            for each (var addr in addrArr) {
                if (!validateHostPortAddress(addr)) {
                    errorMsg("Invalid internet address or port for property " + propName + " value: [" + propUserValue +
                        "] problem at: '" + addr + "'");
                    errorMsg("Value must be in the format: 'internet-address:port-num', if more than one value, separate values with commas ','");
                    exitCode = EXIT_CODE_FAILED;
                    valid = false;
                }
            }
        }
    }
    else {
        valid = false; // value not specified, but no error
    }

    // validate value
    if (valid) {
        configItemRef.value = value; // use trimmed value
    }
}


function configureCodestation() {
    if (configuration.REPLICATION_SERVER_URL.value !== null) {
        return;
    }
    var i;
    var statuses;
    var GeoTagListParser = Packages.com.ibm.uclab.csrepl.ptrstore.GeoTagListParser;

    print("--------------------------------------------------------------------------------");
    print("The relay supports caching artifacts downloaded by agents using this relay. This");
    print("is useful in reducing the bandwidth usage on the central server during large ");
    print("deployments, and is recommended for configurations involving thousands of agents.");
    print("");

    configuration.REPLICATION_ENABLE.value = prompter.promptBoolean(
        "Do you want to cache files on the relay that are downloaded by connected agents?",
        configuration.REPLICATION_ENABLE.value);

    if (configuration.REPLICATION_ENABLE.value) {
        print("--------------------------------------------------------------------------------");
        print("The amount of storage used for replicated artifacts can be limited. Older");
        print("artifacts will be removed to make space for newer ones. The limit can be");
        print("expressed as \"none\", meaning no limit, or an integer number of bytes followed");
        print("by one of the optional scaling factors, 'K', 'M', 'G', or 'T'.");
        print("For example 24 gigabytes can be written as \"25769803776\" or \"24G\".");
        print("");
        configuration.REPLICATION_MAX_CACHE.value = prompter.promptBytes(
            "What is the storage limit for cached artifact storage?",
            configuration.REPLICATION_MAX_CACHE.value);

        print("--------------------------------------------------------------------------------");
        print("Version statuses can be used to control artifact replication. The relay can look");
        print("for component versions with one or more statuses from a list and automatically");
        print("replicate them. The special status '*' can be use to instruct the relay to");
        print("replicate all artifacts.");
        print("");
        statuses = prompter.promptArray("Enter each status for which you want to cache components, one status per line, with an empty line to end the list.");
        for (i = 0; i < statuses.length; i++) {
            statuses[i] = GeoTagListParser.escapeTag(statuses[i]);
        }
        configuration.REPLICATION_GEOTAGS.value = statuses.join(",");
    }

    configuration.REPLICATION_SERVER_URL.value = prompter.prompt(
        "Enter the full web URL for the central server.");

    print("--------------------------------------------------------------------------------");
    print("The relay requires a valid authentication token for distributing artifacts. To");
    print("reduce maintenance overhead, generate a token which will remain valid for an");
    print("extended period of time. If replication is enabled, the user associated with the");
    print("token must have the \"Read Artifact Set List\" server configuration permission.");
    print("");
    print("The token can be generated at: " + configuration.REPLICATION_SERVER_URL.value + "#security/tokens");
    print("");

    configuration.REPLICATION_SERVER_PASS.value = encryptOnce(prompter.prompt(
        "Provide an authentication token for the associated user account on the central server."));
}

function switchToMultiServerFormat() {
    if (configuration.AGENT_RELAY_SERVERS.value !== null) {
        return;
    }
    print("--------------------------------------------------------------------------------");
    print("Agent relays may now be configured for multiple servers in an H.A. cluster.");
    print("This allows agents to failover to another server, should one go down.");
    print("This may be reconfigured at any time by editing " + configuration.AGENT_RELAY_SERVERS.name);
    print("in the agentrelay.properties file.");
    print("");

    var addServer = prompter.promptBoolean("Reconfigure relay now?", false);

    if (addServer) {
        configuration.AGENT_RELAY_SERVERS.value = "";
        do {
            var host = prompter.promptInetAddress("Enter the hostname or address of the server that this relay will connect to.")
            var port = prompter.promptPort("Enter the agent JMS communication port number for this server.", 7918);
            configuration.AGENT_RELAY_SERVERS.value += host + ":" + port;
            addServer = prompter.promptBoolean("Do you want to configure an additional connection for failover scenarios?", false);
            if (addServer) {
                configuration.AGENT_RELAY_SERVERS.value += ",";
            }
        }
        while (addServer);
    }
    else {
        var host = defaultValues.getProperty(OLD_SERVER_HOST_PROPERTY_NAME);
        var port = defaultValues.getProperty(OLD_SERVER_PORT_PROPERTY_NAME);
        configuration.AGENT_RELAY_SERVERS.value = host + ":" + port;
    }

}

function configureKeystoreProperties() {
    if (defaultValues.getProperty(OLD_AGENTRELAY_KEYSTORE_PASS) !== null) {
        configuration.AGENTRELAY_KEYSTORE_PASS.value = defaultValues.getProperty(OLD_AGENTRELAY_KEYSTORE_PASS)
    }
    if (defaultValues.getProperty(OLD_AGENTRELAY_CERT_ALIAS) !== null) {
        configuration.AGENTRELAY_CERT_ALIAS.value = defaultValues.getProperty(OLD_AGENTRELAY_CERT_ALIAS)
    }
    if (defaultValues.getProperty(OLD_AGENTRELAY_CERT_PASS) !== null) {
        configuration.AGENTRELAY_CERT_PASS.value = defaultValues.getProperty(OLD_AGENTRELAY_CERT_PASS)
    }
}
