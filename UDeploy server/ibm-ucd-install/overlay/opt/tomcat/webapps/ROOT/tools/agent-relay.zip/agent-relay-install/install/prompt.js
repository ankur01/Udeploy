/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
load("install/utilities.js");
load("install/inet.js");
importPackage(java.io);

/**
 * This class defines a Prompter which can be used ask the user for input.
 */
function Prompter()
{
    this.lineReader = java.lang.System.console();
    if (!this.lineReader) {
        // This should only happen if the call to console() returns null (most common reason would be the scripting
        // an install)
        this.stdio = java.lang.System["in"];
        this.lineReader = new BufferedReader(new InputStreamReader(this.stdio, "UTF-8"));
        this.insecure = true;
    }

    Prompter.prototype.prompt = function(question, defaultValue, secure) {
        var response = null;

        this.displayBanner();
        while (response == null) {
            print(question);
            if (defaultValue != null) {
                print("[" + defaultValue + "]");
            }
            if (!secure || this.insecure) {
                response = this.lineReader.readLine();
            }
            else {
                response = new java.lang.String(this.lineReader.readPassword()) + "";
            }

            if (response == "") {
                if (defaultValue != null) {
                    response = defaultValue;
                }
            }
        }
        if (!secure) {
            this.displayResponse(response);
        }

        return response;
    }

    Prompter.prototype.promptMultipleChoice = function(question, defaultValue, choices) {
        var response = null;

        if (choices != null) {
            question += " (";
            for (var i = 0; i < choices.length; ++i) {
                question += choices[i];
                if (i < choices.length-1) {
                    question += ", ";
                }
            }
            question += ")";
        }
        question += ": ";

        this.displayBanner();
        while (response == null) {
            print(question);
            if (defaultValue != null) {
                print(" [" + defaultValue + "]");
            }

            response = this.lineReader.readLine();

            if (response == "") {
                if (defaultValue != null) {
                    response = defaultValue;
                }
            }

            var valid = false;
            for (i = 0; i < choices.length; ++i) {
                if (response == choices[i]) {
                    valid = true;
                    break;
                }
            }

            if (!valid) {
                print("Not a valid response must be one of " + choices.toString() + ".");
                response = null;
            }
        }
        this.displayResponse(response);

        return response;
    }

    Prompter.prototype.promptBoolean = function(question, defaultValue) {
        var response = null;
        question += ": ";

        this.displayBanner();
        while (response == null) {
            print(question);
            if (defaultValue != null) {
                if(evalBoolean(defaultValue)) {
                    print("[Y/n]");
                } else {
                    print("[y/N]");
                }
            } else {
                print("[y/n]");
            }
            response = this.lineReader.readLine();
            if (response != "") {
                response = evalBoolean(response);
            } else if (defaultValue != null) {
                response = evalBoolean(defaultValue);
            } else {
                response = null;
            }
        }

        this.displayResponse(response);
        return response;
    }

    Prompter.prototype.promptPort = function(question, defaultValue) {
        var response = Number.NaN;

        question += ": ";
        this.displayBanner();
        while (isNaN(response)) {
            print(question);
            if (defaultValue != null) {
                defaultValue = parseInt(defaultValue);
                if (isNaN(defaultValue)) {
                    throw new Error("The port number was not an integer.");
                }
                if (defaultValue < 0) {
                    throw new Error("The port number must be greater than 0.");
                }
                if (defaultValue > 65535) {
                    throw new Error("The port number must be less than 65535");
                }
                print("[" + defaultValue + "]");
            }
            response = this.lineReader.readLine();

            // interpret response.
            if (response != "") {
                response = parseInt(response);
            } else if (defaultValue != null) {
                response = parseInt(defaultValue);
            } else {
                response = Number.NaN;
            }

            // validate response.
            if (!isNaN(response)) {
                if (response < 0) {
                    print("The port number must be greater than or equal to 0.");
                    response = Number.NaN;
                } else if (response > 65535) {
                    print("The port number must be less than or equal to 65535.");
                    response = Number.NaN;
                }
            }
        }
        
        this.displayResponse(response);
        return response;
    }

    Prompter.prototype.promptHostPortAddressList = function(question, defaultValue) {
        var response = null;

        question += ": ";

        this.displayBanner();
        while (response == null) {
            print(question);
            if (defaultValue != null) {
                assertHostPortAddress(defaultValue);
                print("[" + defaultValue + "]");
            }

            response = this.lineReader.readLine();

            if (response != "") {
                var addrList = response.split(",");
                for (var i = 0; i < addrList.length; i++) {
                    var addr = addrList[i];
                    try {
                        assertHostPortAddress(addr.trim());
                    }
                    catch (err) {
                        print(err.message);
                        print("");
                        response = null;
                        break;
                    }
                }
            }
            else if (defaultValue != null) {
                response = defaultValue;
            }
            else {
                response = null;
            }
        }
        this.displayResponse(response);
        return response;
    }

    Prompter.prototype.promptInetAddress = function(question, defaultValue) {
        var response = null;

        question += ": ";

        this.displayBanner();
        while (response == null) {
            print(question);
            if (defaultValue != null) {
                assertInetAddress(defaultValue);
                print("[" + defaultValue + "]");
            }

            response = this.lineReader.readLine();

            if (response != "") {
                response = response.trim();
                if (!validateInetAddress(response)) {
                    response = null;
                }
            } else if (defaultValue != null) {
                response = defaultValue;
            } else {
                response = null;
            }
        }
        this.displayResponse(response);
        return response;
    }

    Prompter.prototype.promptBytes = function(question, defaultValue) {
        var response = null;
        var limit = null;
        question += ": ";
        
        this.displayBanner();
        
        while (limit == null) {
            print(question);
            if (defaultValue != null) {
                print("[" + defaultValue + "]");
            }
            
            response = this.lineReader.readLine();
            
            if (response != "") {
                response = response.trim();
                limit = parseBytes(response);
                if (limit == null) {
                    print("Invalid byte limit.");
                }
            } else if (defaultValue != null) {
                limit = defaultValue;
            } else {
                limit = null;
            }
        }
        this.displayResponse(response);
        if (limit < 0) {
            return "none";
        }
        return String(limit);
    }

    Prompter.prototype.promptArray = function(question) {
        var response = null;
        var array = [];
        question += ": ";

        this.displayBanner();
        print(question);

        response = "";
        while (response !== null) {
            response = String(this.lineReader.readLine());
            if (response !== null) {
                response = response.trim();
            }
            if (response === "") {
                response = null;
            }
            if (response !== null) {
                array.push(response);
            }
        }
        return array;
    }

    Prompter.prototype.displayBanner = function() {
        print("--------------------------------------------------------------------------------");
    }

    Prompter.prototype.displayResponse = function(response) {
        print("Response: " + response);
        print("");
    }
}
