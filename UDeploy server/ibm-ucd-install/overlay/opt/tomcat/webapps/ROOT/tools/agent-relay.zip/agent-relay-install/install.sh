#!/bin/sh
# Licensed Materials - Property of IBM Corp.
# IBM UrbanCode Build
# IBM UrbanCode Deploy
# IBM UrbanCode Release
# IBM AnthillPro
# (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
#
# U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
# GSA ADP Schedule Contract with IBM Corp.

# now change the dir to the root of the installer
SHELL_NAME=$0
SHELL_PATH=`dirname ${SHELL_NAME}`

if [ "." = "$SHELL_PATH" ]
then
   SHELL_PATH=`pwd`
fi
cd "${SHELL_PATH}"

FIPS_FLAG=$1
FIPS_ARG=
if [ "-fips" = "$FIPS_FLAG" ]
then
   FIPS_ARG=-Dcom.ibm.jsse2.usefipsprovider=true
fi

javaCmd=java
$javaCmd $FIPS_ARG -cp "install/*" org.mozilla.javascript.tools.shell.Main install/install.js
