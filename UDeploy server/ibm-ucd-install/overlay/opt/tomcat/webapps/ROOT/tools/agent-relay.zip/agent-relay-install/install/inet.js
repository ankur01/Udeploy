/*
* Licensed Materials - Property of IBM Corp.
* IBM UrbanCode Build
* IBM UrbanCode Deploy
* IBM UrbanCode Release
* IBM AnthillPro
* (c) Copyright IBM Corporation 2002, 2014. All Rights Reserved.
*
* U.S. Government Users Restricted Rights - Use, duplication or disclosure restricted by
* GSA ADP Schedule Contract with IBM Corp.
*/
function assertInetAddress(addr) {
    if (!validateInetAddress(addr)) {
        throw new Error("The address '" + addr + " is not a valid internet address.");
    }
}

function validateInetAddress(addr) {
    try {
        var isIpAddress = validateInet4Address(addr);
        if (!isIpAddress) {
            java.net.InetAddress.getByName(addr);
            isIpAddress = true;
        }
        return isIpAddress;
    } catch (e) {
        return false;
    }
}

function validateInet4Address(addr) {
    var inet4Pattern = /([0-9]+)\.([0-9]+)\.([0-9]+)\.([0-9]+)$/;
    var match = inet4Pattern.exec(addr);
    if (match != null) {
        var octet0 = parseInt(match[1]);
        var octet1 = parseInt(match[2]);
        var octet2 = parseInt(match[3]);
        var octet3 = parseInt(match[4]);

        if (    !isNaN(octet0)  && !isNaN(octet1)   &&
                !isNaN(octet2)  && !isNaN(octet3)   &&
                octet0 >= 0     && octet0 <= 255    &&
                octet1 >= 0     && octet1 <= 255    &&
                octet2 >= 0     && octet2 <= 255    &&
                octet3 >= 0     && octet3 <= 255    )
        {
            return true;
        }
    }
    return false;
}

function assertHostPortAddress(addr) {
    if (!validateHostPortAddress(addr)) {
        throw new Error("The address '" + addr + "' does not contain a valid hostname and/or port.");
    }
}

function validateHostPortAddress(addr) {
    var splitArr = addr.split(":");
    if (splitArr.length != 2) {
        return false;
    }

    var host = splitArr[0];
    var port = parseInt(splitArr[1], 10);

    return validatePort(port) && validateInetAddress(host);
}

function validatePort(port) {
    return port > 0 && port <= 65535;
}